import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Set;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.mindrot.jbcrypt.BCrypt;


public class BEHandler implements BcryptService.Iface {
	public List<String> hashPassword(List<String> password, short logRounds)
			throws IllegalArgument, org.apache.thrift.TException {
        System.out.println("Backend gets the hashPassword request");
        long startTime = System.currentTimeMillis();
        
		try {
			
			// Future<List<String>> ret1 = new Future<List<String>>();
			
			// Future<List<String>> ret2 = new Future<List<String>>();

			ExecutorService cachedThreadPool = Executors.newCachedThreadPool();
        	List<Future> futureList = new ArrayList<Future>();
			
			int mid = password.size() / 2;

			Callable<List<String>> task1 = () -> {
				try {
					List<String> ret1 = new ArrayList<>();
					for (String ps : password.subList(0, mid)) {
				
						String oneHash = BCrypt.hashpw(ps, BCrypt.gensalt(logRounds));
						ret1.add(oneHash);
						System.out.println(oneHash);
					}
					return ret1;
					// futureList.add(ret1);
				}
				catch (Exception e) {
					throw new Exception("task interrupted", e);
				}
			};

			Callable<List<String>> task2 = () -> {
				try {
					List<String> ret2 = new ArrayList<>();
					for (String ps : password.subList(mid, password.size())) {
				
						String oneHash = BCrypt.hashpw(ps, BCrypt.gensalt(logRounds));
						ret2.add(oneHash);
						System.out.println(oneHash);
					}
					return ret2;
					// futureList.add(ret1);
				}
				catch (Exception e) {
					throw new Exception("task interrupted", e);
				}
			};

			// new Thread() {
			// 	public void run() {
			// 		for (String ps : password.subList(0, mid)) {
				
			// 			String oneHash = BCrypt.hashpw(ps, BCrypt.gensalt(logRounds));
			// 			ret1.add(oneHash);
			// 			System.out.println(oneHash);
			// 		}
			// 		futureList.add(ret1);
			// 	}
			// }.start();

			// new Thread() {
			// 	public void run() {
			// 		for (String ps : password.subList(mid, password.size())) {
				
			// 			String oneHash = BCrypt.hashpw(ps, BCrypt.gensalt(logRounds));
			// 			ret2.add(oneHash);
			// 			System.out.println(oneHash);
			// 		}
			// 		futureList.add(ret2);
			// 	}
			// }.start();

			ArrayList<String> ret = new ArrayList<String>();

			ExecutorService executor = Executors.newFixedThreadPool(2);
			Future<List<String>> future1 = executor.submit(task1);
			Future<List<String>> future2 = executor.submit(task2);

			ret.addAll(future1.get());
			ret.addAll(future2.get());



			// for ( Future future : futureList) {
			// 	ret.addAll(future.get()); 
			// }

			// for (String ps : password) {
			// 	String oneHash = BCrypt.hashpw(ps, BCrypt.gensalt(logRounds));
			// 	ret.add(oneHash);
			// 	System.out.println(oneHash);
            // }
            
            System.out.println("Time elapsed for hash passward: " + (System.currentTimeMillis() - startTime) + " ms");

			return ret;
		} catch (Exception e) {
			throw new IllegalArgument(e.getMessage());
		}
	}

	public List<Boolean> checkPassword(List<String> password, List<String> hash)
	throws IllegalArgument, org.apache.thrift.TException {
        System.out.println("Backend gets the checkPassword request");
        long startTime = System.currentTimeMillis();

		try {
			List<Boolean> ret = new ArrayList<>();

			for (int i = 0; i < password.size(); i++) {
				String onePwd = password.get(i);
				String oneHash = hash.get(i);
				try {
					ret.add(BCrypt.checkpw(onePwd, oneHash));
				} catch (Exception e) {
					ret.add(false);
				}
            }
            
            System.out.println("Time elapsed for checkPassword: " + (System.currentTimeMillis() - startTime) + " ms");

			return ret;
		} catch (Exception e) {
			throw new IllegalArgument(e.getMessage());
		}
	}

	@Override
	public void beToFeRegistrar(String beHost, int bePort) {
		throw new UnsupportedOperationException();
	}
}
